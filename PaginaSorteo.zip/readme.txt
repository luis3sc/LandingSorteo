1)la pagina de inicio comienza con - crearcuenta.html / login.html
2) al confirmar o validar / logear la cuenta se dirige a terminar de crear cuenta
3) una vez validado y terminado todo carga la pagina de index con sus demas paginas (premios, ganadores)
